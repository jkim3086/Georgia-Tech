import javafx.application.Application;

public class Planetarium extends Application {

}