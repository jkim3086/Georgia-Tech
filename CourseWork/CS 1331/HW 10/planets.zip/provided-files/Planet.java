import javafx.scene.paint.Color;

public enum Planet {

    EARTH(Color.SPRINGGREEN, 1, 1, 1);

    /** DO NOT MODIFY IT'S FOR YOUR OWN GOOD**/
    private final int earthRadius = 35;
    private final int earthDistance = 265;
    private final int earthPeriod = 5;
    /** OK YOU'RE GOOD GO AHEAD AND DO WORK NOW **/


}

