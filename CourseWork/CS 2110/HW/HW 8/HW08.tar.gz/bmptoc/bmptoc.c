// ***** YOUR NAME HERE *****

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

// This is the array into which you will load the raw data from the file
char data_arr[0x36 + 240 * 160 * 4];

int main(int argc, char *argv[]) {

	// 1. Make sure the user passed in the correct number of arguments



	// 2. Open the file; if it doesn't exist, tell the user and then exit



	// 3. Read the file into the buffer then close it when you are done



	// 4. Get the width and height of the image



	// 5. Create header file, and write header contents; close it



	// 6. Create c file, and write pixel data; close it



	return 0;
}

